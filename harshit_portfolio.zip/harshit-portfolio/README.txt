Harshit Dwivedi - Portfolio

Run locally:   npm install   then   npm run dev
Build:         npm run build

Contact form: already set up with Harshit's Web3Forms access key (src/App.tsx).
In the Web3Forms dashboard, set the form's website to the deployed Vercel domain.

Edit content (name, links, skills, experience) in src/data.ts.
